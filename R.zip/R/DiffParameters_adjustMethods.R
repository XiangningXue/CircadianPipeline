adj_minP = function(diffPar.tab = diffPar.tab, p.adjust.method = "BH", alpha = 0.05){

  diffPar.tab$p.combined = pmin(3*pmin(diffPar.tab$p.M, diffPar.tab$p.A, diffPar.tab$p.phase), 1)
  diffPar.tab$q.combined = p.adjust(diffPar.tab$p.combined, p.adjust.method)
  the.BH.p.cutoff = max(diffPar.tab$p.combined[diffPar.tab$q.combined<alpha])
  diffPar.tab$ind.global = diffPar.tab$q.combined <alpha
  diffPar.tab$ind.M = diffPar.tab$p.M<the.BH.p.cutoff/3
  diffPar.tab$ind.A = diffPar.tab$p.A<the.BH.p.cutoff/3
  diffPar.tab$ind.phase = diffPar.tab$p.phase<the.BH.p.cutoff/3

  return(diffPar.tab)
}
