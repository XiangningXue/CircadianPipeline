#the least square cosinor package
#' Title Fit two-component cosinor with OLS for one gene
#'
#'This function fit the expression and time to this function \deqn{y = M1+A1(cos(2\pi/24*t+phase1))+X(M*+A*(cos(2\pi/24*t+phase*)))+\epsilon}, where \eqn{\epsilon \sim N(0, \sigma^2)}; X = 0 for group 1 and X = 1 for group 2.
#'For group 2 the formula can be converted to \deqn{y = M2+A2(cos(2\pi/24*t+phase2))+\epsilon}
#' @param tod a numeric vector. Time of death (e.g. time of expression of the gene). length should be the same as y
#' @param y a numeric vector. Gene expression level.
#' @param alpha a number between 0 to 1. The critical level for the confidence interval
#' @param period The length of the rhythmicity cycle. When it is 24 (default), the signal is circadian.
#'
#' @return a list of rhythmicity parameters
#' \item{M1}{A list of OLS estimate of M1 and the lower and upper limit of M1 corresponding to the critical level alpha}
#' \item{A1}{A list of estimate of A1, sd of A1 and the lower and upper limit of A1 corresponding to the critical level alpha}
#' \item{phase1}{A list of estimate of phase1, sd of phase1 and the lower and upper limit of phase1 corresponding to the critical level alpha}
#' \item{M2}{A list of OLS estimate of M2 and the lower and upper limit of M2 corresponding to the critical level alpha}
#' \item{A2}{A list of estimate of A2, sd of A2 and the lower and upper limit of A2 corresponding to the critical level alpha}
#' \item{phase2}{A list of estimate of phase2, sd of phase2 and the lower and upper limit of phase2 corresponding to the critical level alpha}
#' \item{test}{A list of test result: F statistics, p-value and R2, \eqn{\sigma^2} (the variance of the error term)}
#'
#' @export
#' @examples
#' #Simulate a time series data with 20 time points
#'
#' x.time = runif(20, min = 0, max = 24)
#' m = 5; A = 3; phase = pi/4; sigma = 1
#' y = m+A*cos(2*pi/24*x.time+phase)+rnorm(20, 0, sigma)
#' est = one_cosinor_OLS(tod = x.time, y = y, alpha = 0.05, period = 24)
#'
two_cosinor_OLS = function(tod = time, y = y, alpha = 0.05, period = 24){
  #alpha is the critical level for equal tailed CI
  n = length(tod)
  x1 = cos(2*pi*tod/period)
  x2 = sin(2*pi*tod/period)
  # mat.X = matrix(c(rep(1, n), x1, x2), ncol = 3, byrow = FALSE)
  # mat.XX = t(mat.X)%*%mat.X#mat.XX = mat.S
  mat.S = matrix(c(n, sum(x1), sum(x2),
                   sum(x1), sum(x1^2), sum(x1*x2),
                   sum(x2), sum(x1*x2), sum(x2^2)),
                 nrow = 3, byrow = TRUE)
  vec.d = c(sum(y), sum(y*x1), sum(y*x2))

  mat.S.inv = solve(mat.S)
  est = mat.S.inv%*%vec.d
  m.hat = est[1]
  beta1.hat = est[2]
  beta2.hat = est[3]
  # truth$phase[2]; truth$amplitude[2]; truth$M[502]
  A.hat = sqrt(beta1.hat^2 + beta2.hat^2)

  phase.res = get_phase(beta1.hat, beta2.hat)
  phase.hat = phase.res$phase

  #inference
  TSS = sum((y-mean(y))^2)
  yhat = m.hat + beta1.hat*x1+beta2.hat*x2
  RSS = sum((y-yhat)^2)
  MSS = TSS-RSS
  Fstat = (MSS/2)/(RSS/(n-3))
  pval = stats::pf(Fstat, 2, n-3, lower.tail = FALSE)

  #CI (M and se for A and phi)
  sigma2.hat = RSS/(n-3)
  sigma.hat = sqrt(sigma2.hat)
  CI.m.hat.radius = stats::qt(1-alpha/2, n-3)*sigma.hat*mat.S.inv[1, 1]
  se.A.hat = sigma.hat*sqrt(mat.S.inv[2, 2]^cos(phase.hat)^2
                            -2*mat.S.inv[2, 3]*sin(phase.hat)*cos(phase.hat)
                            +mat.S.inv[3, 3]*sin(phase.hat)^2)
  se.phase.hat = sigma.hat*sqrt(mat.S.inv[2, 2]^sin(phase.hat)^2
                                +2*mat.S.inv[2, 3]*sin(phase.hat)*cos(phase.hat)
                                +mat.S.inv[3, 3]*cos(phase.hat)^2)/A.hat

  #CI (derive conservative CI for phi)
  B11 = sum((x1-mean(x1))^2)
  B12 = sum((x1-mean(x1))*(x2-mean(x2)))
  B22 = sum((x2-mean(x2))^2)
  C1 = -(B11*beta1.hat+B12*beta2.hat)/(B22*beta2.hat+B12*beta1.hat)
  C2 = -(2*sigma2.hat*stats::qf(1-alpha, 2, n-3)-2*B12*beta1.hat*beta2.hat-B11*beta1.hat^2-B22*beta2.hat^2)/(B22*beta2.hat+B12*beta1.hat)
  D1 = B22*C1^2+B11+2*B12*C1
  D2 = 2*B22*C1*C2+2*B12*C2-(B12*beta1.hat+B22*beta2.hat)*C1-B11*beta1.hat-B12*beta2.hat
  D3 = B22*C2^2-(B12*beta1.hat+B22*beta2.hat)*C2

  #calculate CI of phi
  #check if 0 is in ellipse
  zero.in.ellipse = B11*beta1.hat^2+2*B12*beta1.hat*beta2.hat+B22*beta2.hat^2 < 2*sigma2.hat*stats::qf(1-alpha, 2, n-3)
  if(!zero.in.ellipse){
    delta.poly = D2^2-4*D1*D3
    if(delta.poly<0){
      phi.lower.limit = list(tan = -99, phase = -99)
      phi.upper.limit = list(tan = -99, phase = -99)
    }else{
      phi.beta1.roots = c((-D2-sqrt(delta.poly))/(2*D1), (-D2+sqrt(delta.poly))/(2*D1))
      phi.beta2.roots = C1*phi.beta1.roots+C2

      # phi.limit1 = get_phase(phi.beta1.roots[1], phi.beta2.roots[1])
      # phi.limit2 = get_phase(phi.beta1.roots[2], phi.beta2.roots[2])

      #change to adjusted phi limits
      phi.limits = get_phaseForCI(b1.x = beta1.hat, b2.x = beta2.hat,
                                  b1.r1 = phi.beta1.roots[1], b2.r1 = phi.beta2.roots[1],
                                  b1.r2 = phi.beta1.roots[2], b2.r2 = phi.beta2.roots[2])
      phi.lower.limit = phi.limits$phi.lower.limit
      phi.upper.limit = phi.limits$phi.upper.limit
    }
  }else{
    phi.lower.limit = list(tan = 99, phase = 99)
    phi.upper.limit = list(tan = 99, phase = 99)
  }

  #calculate CI of A
  #calculate normal ellipse parameters
  ellipse.parameters = solve.ellipse.parameters(a = B11, b = B22, c = 2*B12,
                                                d = -2*(B11*beta1.hat+B12*beta2.hat),
                                                e = -2*(B12*beta1.hat+B22*beta2.hat),
                                                f = B11*beta1.hat^2+B22*beta2.hat^2+2*B12*beta1.hat*beta2.hat-2*sigma2.hat*stats::qf(1-alpha, 2, n-3))
  angle.point.newOrigin.major =
    get.angle_point.newOrigin.major(x0 = ellipse.parameters$x0,
                                    y0 = ellipse.parameters$y0,
                                    theta.rotate = ellipse.parameters$theta.rotate)
  r.point.to.center = sqrt(ellipse.parameters$x0^2+ellipse.parameters$y0^2)
  x.new = r.point.to.center*cos(angle.point.newOrigin.major)
  y.new = r.point.to.center*sin(angle.point.newOrigin.major)

  #check the position of the new origin to the ellipse
  if(x.new==0&y.new==0){
    A.limit1 = ellipse.parameters$minor
    A.limit2 = ellipse.parameters$major
  }else if(x.new==0){
    A.limit1 = abs(ellipse.parameters$minor-y.new)
    A.limit2 = ellipse.parameters$minor+y.new
  }else if(y.new==0){
    A.limit1 = abs(ellipse.parameters$major-x.new)
    A.limit2 = ellipse.parameters$major+x.new
  }else if(x.new!=0&y.new!=0){
    x.new = abs(x.new)
    y.new = abs(y.new)
    fun.t = function(t){
      (ellipse.parameters$major*x.new/(t+ellipse.parameters$major^2))^2+
        (ellipse.parameters$minor*y.new/(t+ellipse.parameters$minor^2))^2-1
    }

    # root.upper = 50
    # while(fun.t(-ellipse.parameters$minor^2+0.0001)*fun.t(root.upper)>0){
    #   root.upper = root.upper+50
    # }
    #    root1 = uniroot(fun.t, c(-ellipse.parameters$minor^2, root.upper),extendInt="downX")$root
    root1 = stats::uniroot(fun.t, c(-ellipse.parameters$minor^2, -ellipse.parameters$minor^2+50),extendInt="downX")$root
    x.root1 = ellipse.parameters$major^2*x.new/(root1+ellipse.parameters$major^2)
    y.root1 = ellipse.parameters$minor^2*y.new/(root1+ellipse.parameters$minor^2)
    dmin = sqrt((x.new-x.root1)^2+(y.new-y.root1)^2)

    # root.lower = -50
    # while(fun.t(-ellipse.parameters$major^2-0.0001)*fun.t(root.lower)>0){
    #   root.lower = root.lower-50
    # }
    #root2 = uniroot(fun.t, c(root.lower, -ellipse.parameters$major^2-0.0001), extendInt="yes")$root
    root2 = stats::uniroot(fun.t, c(-ellipse.parameters$major^2-50, -ellipse.parameters$major^2), extendInt="upX")$root
    # root2 = uniroot(fun.t, c(-ellipse.parameters$major^2-50, -ellipse.parameters$major^2), extendInt="yes")$root
    # root2 = uniroot(fun.t, c(-ellipse.parameters$major^2-50, -ellipse.parameters$major^2), extendInt="no")$root
    x.root2 = ellipse.parameters$major^2*x.new/(root2+ellipse.parameters$major^2)
    y.root2 = ellipse.parameters$minor^2*y.new/(root2+ellipse.parameters$minor^2)
    dmax = sqrt((x.new-x.root2)^2+(y.new-y.root2)^2)

    A.limit1 = min(dmin, dmax)
    A.limit2 = max(dmin, dmax)
  }

  if(zero.in.ellipse){
    A.limit1 = 0
  }


  #output
  out = list(M = list(est = m.hat,
                      CI_M = c(m.hat-CI.m.hat.radius, m.hat+CI.m.hat.radius)),
             A = list(est = A.hat,
                      sd = se.A.hat,
                      #CI_temp = c(A.hat-qt(1-alpha/2, n-3)*se.A.hat, A.hat+qt(1-alpha/2, n-3)*se.A.hat),
                      CI_A = c(A.limit1, A.limit2)), #conservative CI
             phase = list(est = phase.hat,
                          sd = se.phase.hat,
                          #CI_temp = c(phase.hat-qt(1-alpha/2, n-3)*se.phase.hat, phase.hat+qt(1-alpha/2, n-3)*se.phase.hat),
                          #tan = phase.res$tan,
                          #CI_tan = c(phi.lower.limit$tan, phi.upper.limit$tan),
                          CI_phase = c(phi.lower.limit$phase, phi.upper.limit$phase)), #conservative CI
             test = list(Fstat = Fstat,
                         pval = pval,
                         R2 = MSS/TSS,
                         sigma2 = sigma2.hat))
  return(out)

}
